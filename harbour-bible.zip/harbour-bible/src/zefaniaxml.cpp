#include "zefaniaxml.h"
#include <QFile>
#include <QTextStream>
#include <QXmlQuery>
#include <QXmlResultItems>
#include <QXmlItem>
#include <QDebug>
#include <QVariantMap>

/**
 * Reads all verses of a chapter in a book.
 *
 * Hint: We usually use trimmed() QStrings here because there is a lot of useless content like newline, spaces etc
 * @brief ZefaniaXML::readVerses
 * @param filename the filename to be parsed - must be ZefaniaXML encoded
 * @param bookNumber the bible book number
 * @param chapter the chapter number
 * @return a list of QStrings, each represents a verse
 */
QList<QString> ZefaniaXML::readVerses(const QString &filename, const QString &bookNumber, const QString &chapter) {
    QFile sourceDocument;
    sourceDocument.setFileName(filename);
    sourceDocument.open(QIODevice::ReadOnly);
    QXmlQuery query;
    query.bindVariable("inputDocument", &sourceDocument);
    query.setQuery("doc($inputDocument)/XMLBIBLE/BIBLEBOOK[@bnumber=" + bookNumber + "]/CHAPTER[@cnumber=" + chapter + "]/VERS");
    QXmlResultItems xmlResultItems;
    QList<QString> resultList;
    if (query.isValid()) {
        query.evaluateTo(&xmlResultItems);
        QXmlItem item(xmlResultItems.next());
        while (item.isNode()) { // XPath expression selects nodes only (null != isNode())
            query.setFocus(item);
            query.setQuery("name()");
            QString tagName;
            query.evaluateTo(&tagName);
            if (tagName.indexOf("VERS") != -1) {
                QString verseNumber;
                query.setQuery("@vnumber/string()");
                query.evaluateTo(&verseNumber);
                resultList.append(verseNumber.trimmed() + ". ");
                QXmlResultItems verseElements;
                query.setQuery("child::node()"); // select all children nodes
                query.evaluateTo(&verseElements);
                QXmlItem verseElement(verseElements.next());
                while (!verseElement.isNull()) {
                    query.setFocus(verseElement);
                    query.setQuery("name()");
                    QString verseElementTagName;
                    query.evaluateTo(&verseElementTagName);
                    QString textContent;
                    query.setQuery("string()");
                    query.evaluateTo(&textContent);
                    if (verseElementTagName.trimmed().isEmpty()) { // text node - because they have no tag name
                        QString currentVerseContent = resultList.takeLast();
                        currentVerseContent.append(textContent.remove(QRegExp("[\\n\\t\\r]")));
                        resultList.append(currentVerseContent);
                        //qDebug() << "TextContent: " << textContent.remove(QRegExp("[\\n\\t\\r]"));
                    } else {
                        if (verseElementTagName.indexOf("STYLE") != -1 || verseElementTagName.indexOf("em") != -1) { // we ignore all style and emphasis attributes - we just need the text
                            QString currentVerseContent = resultList.takeLast();
                            currentVerseContent.append(textContent.remove(QRegExp("[\\n\\t\\r]")));
                            resultList.append(currentVerseContent);
                        } else if (verseElementTagName.indexOf("gr") != -1) { // special handling for greek nodes
                            QString currentVerseContent = resultList.takeLast();
                            // first - append text
                            currentVerseContent.append(textContent.remove(QRegExp("[\\n\\t\\r]")));
                            // second - append 'str' and 'rmac' attributes in brackets
                            QString strAttribute;
                            query.setQuery("@str/string()");
                            query.evaluateTo(&strAttribute);
                            QString rmac;
                            query.setQuery("@rmac/string()");
                            query.evaluateTo(&rmac);
                            currentVerseContent.append("[" + strAttribute.trimmed() + " " + rmac.trimmed() + "] "); // change appearance of Strongs-comments here
                            resultList.append(currentVerseContent);
                        } else if (verseElementTagName.indexOf("DIV") != -1) { // a note is always within a DIV node
                            QString currentVerseContent = resultList.takeLast();
                            currentVerseContent.append(" [" + textContent.remove(QRegExp("[\\n\\t\\r]")) + "]");
                            resultList.append(currentVerseContent);
                        } else {
                            //qDebug() << "Unknown tag found:" << verseElementTagName.trimmed() << " with text: " << textContent.remove(QRegExp("[\\n\\t\\r]"));
                        }
                        //qDebug() << verseElementTagName.trimmed() << " : " << textContent.remove(QRegExp("[\\n\\t\\r]"));
                    }
                    verseElement = verseElements.next();
                }
            }
            item = xmlResultItems.next();
        }
    }
    return resultList;
}
