#ifndef ZEFANIAXML
#define ZEFANIAXML

#include <QObject>

class ZefaniaXML : public QObject
{
    Q_OBJECT
public:
    Q_INVOKABLE QList<QString> readVerses(const QString &filename,const QString &bookNumber, const QString &chapter);
signals:

public slots:
};

#endif // ZEFANIAXML

