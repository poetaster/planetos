<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>BannerBookmarks</name>
    <message>
        <source>Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BannerBooks</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
</context>
<context>
    <name>BannerSearch</name>
    <message>
        <source>type here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Complete Bible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current Book</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current Chapter</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FirstPage</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
    <message>
        <source>OLD TESTAMENT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Genesis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exodus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Leviticus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lev</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Numbers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Num</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Deuteronomy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Deut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Joshua</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Josh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Judges</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Judg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ruth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1 Samuel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sam¹</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2 Samuel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sam²</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1 Kings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Kgs¹</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2 Kings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Kgs²</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1 Chronicles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chr¹</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2 Chronicles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chr²</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ezra</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ezr</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nehemiah</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Neh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Esther</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Est</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Job</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Psalms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ps</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Proverbs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Prov</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ecclesiastes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Eccl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Song of Salomon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Song</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Isaiah</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Isa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Jeremiah</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Jer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lamentations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lam</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ezekiel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ezk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Daniel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hosea</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Joel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Obadiah</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Obad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Jonah</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Jon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Micah</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nahum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nah</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Habakkuk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zephaniah</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zeph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Haggai</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zechariah</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zech</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Malachi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>NEW TESTAMENT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>NT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Matthew</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Matt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Luke</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>John</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Joh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Acts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Act</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Romans</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1 Corinthians</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cor¹</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2 Corinthians</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cor²</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Galatians</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ephesians</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Eph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Philippians</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Colossians</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Col</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1 Thessalonians</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Thes¹</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2 Thessalonians</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Thes²</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1 Timothy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tim¹</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2 Timothy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tim²</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Titus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Philemon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hebrews</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Heb</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>James</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Jas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1 Peter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pet¹</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2 Peter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pet²</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1 John</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>John¹</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2 John</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>John²</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>3 John</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>John³</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Jude</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Jud</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Revelation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rev</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>backward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>foreward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>← copy    </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>    copy →</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bible</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SettingsPage</name>
    <message>
        <source>Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fontsize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>tiny</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>extra small</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>small</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>medium</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>large</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dark page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>light page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[Load]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load ZefaniaXML Bible #1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load ZefaniaXML Bible #2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>comments unmarked</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sailfish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>disabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Screen blanking</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>[comments marked]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>standard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bibles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>single - fullscreen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dual - splitscreen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Layout books</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
