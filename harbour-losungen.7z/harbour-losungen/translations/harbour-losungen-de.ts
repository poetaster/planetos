<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>FirstPage</name>
    <message>
        <source>Losungsdatei</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Datum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LEHRTEXT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>XML Datei wählen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LOSUNG</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SecondPage</name>
    <message>
        <source>Info</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
