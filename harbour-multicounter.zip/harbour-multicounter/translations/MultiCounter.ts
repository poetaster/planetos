<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>CoverPage</name>
    <message>
        <location filename="../qml/cover/CoverPage.qml" line="8"/>
        <source>MultiCounter</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FirstPage</name>
    <message>
        <location filename="../qml/pages/FirstPage.qml" line="45"/>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/FirstPage.qml" line="49"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/FirstPage.qml" line="54"/>
        <source>MultiCounter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/FirstPage.qml" line="98"/>
        <source>Start [</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/FirstPage.qml" line="110"/>
        <source>Step [</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SetupPage</name>
    <message>
        <location filename="../qml/pages/SetupPage.qml" line="44"/>
        <source>SETTINGS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/SetupPage.qml" line="50"/>
        <source>GRID LAYOUT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/SetupPage.qml" line="61"/>
        <source>counters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/SetupPage.qml" line="73"/>
        <source>columns</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/SetupPage.qml" line="79"/>
        <source>EDIT COUNTERS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/SetupPage.qml" line="110"/>
        <source>Clear All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/SetupPage.qml" line="118"/>
        <source>Create</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/SetupPage.qml" line="155"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/SetupPage.qml" line="168"/>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/pages/SetupPage.qml" line="197"/>
        <source>Step</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
