<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>FirstPage</name>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MultiCounter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Step: </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SetupPage</name>
    <message>
        <source>SETTINGS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>counters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>columns</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clear All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Step</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save &amp; Create</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
